package readFromCSVFile;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

//import org.cloudbus.cloudsim.examples.power.random.RandomConstants;
/**
 * 
 * @author anit
 *
 * Have to call two functions from outside to get some release time from the csv file
 * 1. create object by Constructor with the csv file path as input which sets the releaseTimeArray
 * 2. Object.getReleaseTimeArray() which returns the ArrayList of release time
 * 
 * Constructor of RealReleaseTimeFromCSVFile.java is invoked from CSVFileWrite.Java -> main()
 * to read from the input file which contains various information including ReleaseTime of 27000+ VMs 
 * and to create a random ReleaseTime distribution of a smaller set of VMs.
 * 
 * Done in Two steps:
 * 	 * Step 1: generateRandomNumberArray() is invoked to obtain a set of Random Integers
	 * Each of these Random Integers denotes the Row Index of a particular VM from the input CSV file of 27000+ VMs  
	 * 
	 * Step 2: ReleaseTime of that particular VM is retrieved through invoking getAReleaseTimeFromCSVFile()
 */

public class RealReleaseTimeFromCSVFile 
{
	
	private static final String COMMA_DELIMITER = ",";
	//random numbers of randomNumberArray denote selected row numbers of the given csv fie
	private ArrayList<Integer> randomNumberArray = new ArrayList<Integer>();
	//releaseTimeArray holds the list of VM release time retrieved from given csv file
	private ArrayList<Double> releaseTimeArray = new ArrayList<Double>(); 
	//totalRowCount denotes the total number of rows in the given input csv file
	private int totalRowCount;
	
	public int getTotalRowCount() {
		return totalRowCount;
	}

	public void setTotalRowCount(int totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/*
	private void generateRandomNumberArray()
	{
		int randomValue;
		Random random = new Random();
		HashSet<Integer> used = new HashSet<Integer>();
		ArrayList<Integer> randomNumberArrayList = new ArrayList<Integer>();
		for (int i = 0; i < RandomConstants.NUMBER_OF_VMS; i++) 
		{
			// int randomNum = rand.nextInt((max - min) + 1) + min;
			randomValue = random.nextInt((this.getTotalRowCount() - 1) + 1) +1;
		    //int add = (int)(Math.random() * 30); //this is the int we are adding
		    while (used.contains(randomValue)) 
		    { //while we have already used the number
		    	//generate a new one because it's already used
		    	randomValue = random.nextInt((this.getTotalRowCount() - 1) + 1) +1;	    
		    }
		    //by this time, add will be unique
		    randomNumberArrayList.add(randomValue);
		    used.add(randomValue);
		}// end of for
		
		this.setRandomNumberArray(randomNumberArrayList);
	}
	
	*/
	
	
	/**
	 * 
	 * @param totalNumberOfCloudlets
	 * 
	 * generateRandomNumberArray() generates an array of random numbers. 
	 * Size of the array is the number of VMs in the output ReleaseTime distribution
	 * Value of a random number is ranging [1 : Total Number of VMs in the given Input File]
	 * 
	 */
	private void generateRandomNumberArray(int totalNumberOfCloudlets)
	{
		int randomValue;
		Random random = new Random();
		HashSet<Integer> used = new HashSet<Integer>();
		ArrayList<Integer> randomNumberArrayList = new ArrayList<Integer>();
		
		for (int i = 0; i < totalNumberOfCloudlets; i++) 
		{
			// int randomNum = rand.nextInt((max - min) + 1) + min;
			randomValue = random.nextInt((this.getTotalRowCount() - 1) + 1) +1;
		    
			/*
			 * In order to avoid Repetative random numbers
			 * While we keep finding previously generated random number
			 * keep generating a new one because it's already used
			 */
			while (used.contains(randomValue)) 
		    { 
		    	randomValue = random.nextInt((this.getTotalRowCount() - 1) + 1) +1;	    
		    }
		    //by this time, add will be unique
		    randomNumberArrayList.add(randomValue);
		    used.add(randomValue);
		}// end of for
		
		this.setRandomNumberArray(randomNumberArrayList);
	}
	
	
	public ArrayList<Integer> getRandomNumberArray() 
	{
		return this.randomNumberArray;
	}

	public void setRandomNumberArray(ArrayList<Integer> randomNumberArray) {
		this.randomNumberArray = randomNumberArray;
	}

	public ArrayList<Double> getReleaseTimeArray() {
		return releaseTimeArray;
	}
	
	public void setReleaseTimeArray(ArrayList<Double> releaseTimeArray) {
		this.releaseTimeArray = releaseTimeArray;
	}
		
	/**
	 * 
	 * @param inputFileName
	 * 
	 * Counts the total number of rows or VMs in the input file (i.e., in inputFileName)
	 */
	private void countTotalRowNumber(String inputFileName) 
	{
		// TODO Auto-generated method stub
		FileReader fr = null;
		BufferedReader readBufferFromFile = null;
		
		try 
		{
	        fr = new FileReader(new File(inputFileName));     
	        readBufferFromFile = new BufferedReader(fr);
	        int countRows = 0;

	        String entireLine = "";       
	        /*
	         *  key line activate later to avoid the column headings
	        entireLine = readBufferFromFile.readLine();
	        */
	        entireLine = readBufferFromFile.readLine();
	        
	        while((entireLine = readBufferFromFile.readLine())!= null && !(entireLine.equals("-1")))
	        {
	        	countRows++;
	        	//String[] cellValues = entireLine.split(","); 
	        }
	        
	        this.setTotalRowCount(countRows);

		}
		catch (IOException e) 
	    {

	           e.printStackTrace();

	    }//end of catch
		finally 
	    {
			if(readBufferFromFile != null)
			{
				try {
					readBufferFromFile.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}   
			if(fr != null)
			{
				try {
					fr.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

	    }// end of finally of end of closing all files

	} // end of countTotalRowNumber(String inputFileName) 

	
	/**
	 * 
	 * @param rowIndex
	 * @param inputFileName
	 * @return
	 * 
	 * Returns ReleaseTime of the VM having the Row Index in the input CSV file as provided in rowIndex parameter
	 * 
	 */
	private double getAReleaseTimeFromCSVFile(int rowIndex, String inputFileName)
	{
		FileReader fr = null;
		BufferedReader readBufferFromFile = null;
		int countTraversedRows = 0;
		double retrievedReleaseTime = 0.0;
		
		try 
		{
	        fr = new FileReader(new File(inputFileName));     
	        readBufferFromFile = new BufferedReader(fr);
	        String entireLine = "";
	        String[] cellValues;
	        
	        entireLine = readBufferFromFile.readLine();
	        
	        while((entireLine = readBufferFromFile.readLine())!= null && !(entireLine.equals("-1")))
	        {
	        	countTraversedRows++;
	        	if(countTraversedRows == rowIndex)
	        	{
	        		cellValues = entireLine.split(",");
	        		retrievedReleaseTime = Double.parseDouble(cellValues[3]);
	        		break;
	        	}
	
	        }//end of while        
	        readBufferFromFile.close();
	        fr.close();        
		}// end of try
		catch (IOException e) 
	    {

	           e.printStackTrace();

	    }//end of catch
		finally 
	    {
			if(readBufferFromFile != null)
			{
				try {
					readBufferFromFile.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}        
			if(fr != null)
			{
				try {
					fr.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

	    }// end of finally of end of closing all files

		return retrievedReleaseTime*60;	
	}
	
	/*
	//checked works fine
	public RealReleaseTimeFromCSVFile(String inputFileName)
	{
		double retrievedReleaseTime = 0.0;
		//First count the total number of rows in the given input csv file
		this.countTotalRowNumber(inputFileName); //Works fine checked
		//Second, generate array of repetative random Integer numbers 
		//ranging from 1 to total number of rows in the given rows
		//these random numbers denote the row index of the input csv file
		//those row values would be retrieved as VM release time
		this.generateRandomNumberArray(); //works fine checked
		ArrayList<Integer> randomNumberArrayList = new ArrayList<Integer>();
		randomNumberArrayList = this.getRandomNumberArray();
		Iterator<Integer> iteratorRandomNumberArrayList = randomNumberArrayList.iterator();
		//retrieve the corresponding release time
		while(iteratorRandomNumberArrayList.hasNext())
		{
			//getAReleaseTimeFromCSVFile() works fine checked
			retrievedReleaseTime = getAReleaseTimeFromCSVFile(iteratorRandomNumberArrayList.next(), inputFileName);
			this.releaseTimeArray.add(retrievedReleaseTime);
		}	
		
	}//end of static function ReadFromCSVFile()
	*/
	
	/**
	 * 
	 * @param inputFileName
	 * @param totalNumberOfCloudlets
	 * 
	 * Step 1: generateRandomNumberArray() is invoked to obtain a set of Random Integers
	 * Each of these Random Integers denotes the Row Index of a particular VM from the input CSV file of 27000+ VMs  
	 * 
	 * Step 2: ReleaseTime of that particular VM is retrieved through invoking getAReleaseTimeFromCSVFile()
	 * 
	 */
		public RealReleaseTimeFromCSVFile(String inputFileName, int totalNumberOfCloudlets)
		{
			double retrievedReleaseTime = 0.0;
			this.countTotalRowNumber(inputFileName);
			/**
			 * First, generate an array of random Integer numbers. 
			 * Array size is the number of VMs in the ReleaseTime distribution 
			 * ranging [1 : Total Number of VMs in the given input CSV file] 
			 * These random numbers denote the row indexes of the input CSV file 
			 * ReleaseTime Values found in those particular row indexes of the input CSV file would be retrieved
			*/
			this.generateRandomNumberArray(totalNumberOfCloudlets); //works fine checked
			ArrayList<Integer> randomNumberArrayList = new ArrayList<Integer>();
			randomNumberArrayList = this.getRandomNumberArray();
			Iterator<Integer> iteratorRandomNumberArrayList = randomNumberArrayList.iterator();
			
			/**
			 * Retrieving the corresponding release time through invoking getAReleaseTimeFromCSVFile()
			 * 
			 */
			while(iteratorRandomNumberArrayList.hasNext())
			{
				/*
				 * getAReleaseTimeFromCSVFile() returns the ReleaseTime of a particular VM 
				 * having the given row index in the input CSV file
				 */
				retrievedReleaseTime = getAReleaseTimeFromCSVFile(iteratorRandomNumberArrayList.next(), inputFileName);
				this.releaseTimeArray.add(retrievedReleaseTime);
			}	
			
		}//end of static function ReadFromCSVFile()

	
	public RealReleaseTimeFromCSVFile() {
		super();
	}
	
	

}
