package csvfilewrite;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

//import org.cloudbus.cloudsim.examples.power.planetlab.SRTDVMC_StochasticRealReleaseTime_JAN2014_PlanetLab_3March;

import readFromCSVFile.RealReleaseTimeFromCSVFile;

//import writeInCSVFile.WriteInCSVFile;
/**
 * 
 * @author anit
 * 
 * The following program is intended to create a random distribution of duration of existence, aka ReleaseTime of 1000 VMs. 
 * ReleaseTime of 1000 VMs are randomly selected from a total of 27024 VMs 
 * which were hosted in a Cloud data centers, namely Nectar Cloud in January 2014. 
 * 
 * To do so, in main(), we simply invoke 3 functions:
 * 
 * First, the constructor of RealReleaseTimeFromCSVFile.java is invoked
 * which reads from "workload/datafiles__nectar/2014-JAN.CSV" containing various information of 27024 VMs 
 * and creates a random distribution of lifetime of 1000 VMs
 * 
 * Second, getReleaseTimeArray() of RealReleaseTimeFromCSVFile.java is invoked from main()
 * which returns that random distribution of lifetime of 1000 VMs 
 * 
 * Finally, WriteReleaseTimeArrayInCSVFile(ArrayList<Double>) is invoked from main()
 * which writes that random distribution of lifetime of 1000 VMs in "Output/OutputRandomlySelectedReleaseTime.CSV"
 * 
 */

public class CSVFileWrite {

	private static String outputFileDirectory = CSVFileWrite.class.getClassLoader().getResource("Output").getPath();
	private static String outputFileName = "OutputRandomlySelectedReleaseTime.CSV";
	private static String outputFilePath = outputFileDirectory + "/" + outputFileName;
	
	private static FileWriter fw;//----------For outout csv file------
    
	static String directoryOfRealReleaseTimeCSVFile = CSVFileWrite.class.getClassLoader().getResource("workload/datafiles__nectar").getPath();
	static String realReleaseTimeCSVFileName = "2014-JAN.CSV";
	static String realReleaseTimeCSVFilePath = directoryOfRealReleaseTimeCSVFile+"/"+realReleaseTimeCSVFileName;
	
	
	public static void WriteReleaseTimeArrayInCSVFile(ArrayList<Double> realReleaseTimeArray)
	{
	
		try 
		{
	        
	        fw = new FileWriter(new File(outputFilePath)); //output file
	        Iterator<Double> realReleaseTimeArrayIterator = realReleaseTimeArray.iterator();
	        
	        while(realReleaseTimeArrayIterator.hasNext())
	        {		
        		fw.append(realReleaseTimeArrayIterator.next().toString());
	        	fw.append(System.lineSeparator());	
	        }
	        fw.flush();
	        fw.close();
		}
		catch (IOException e) 
	    {

	           e.printStackTrace();

	    }
		
	}	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RealReleaseTimeFromCSVFile realReleaseTimeFromCSVFileObject = new RealReleaseTimeFromCSVFile(realReleaseTimeCSVFilePath, 1000);
		ArrayList<Double> ReleaseTimeArray = new ArrayList<Double>();
		ReleaseTimeArray = realReleaseTimeFromCSVFileObject.getReleaseTimeArray();
		WriteReleaseTimeArrayInCSVFile(ReleaseTimeArray);
		System.out.println("Done.");
	}

}
